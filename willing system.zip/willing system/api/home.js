import request from "@/common/js/request.js"
export const proviceListApi = (params) => {
	return request.get('/index/province_list', {params})
}
export const res1 = () => {
	return request.post('/index/admission_batch',{
			plan_type:'普通类(物理)',
	})
}

export const res2 = () => {
	return request.post('/index/admission_batch',{
			type: '本科',
			plan_type: '艺术类',
	})
}

export const res3 = () => {
	return request.post('/index/admission_batch',{
			type: '本科',
			plan_type: '体育类',
	})
}

export const res4 = () => {
	return request.post('/index/admission_batch',{
			type: '本科',
			plan_type: '三校生类',
	})
}

export const res5 = () => {
	return request.post('/index/admission_batch',{
			type: '本科',
			plan_type: '普通类(历史)',
	})
}

export const ans1 = () => {
	return request.post('/index/admission_batch',{
			type: '专科',
			plan_type: '普通类(物理)'
	})
}

export const ans3 = () => {
	return request.post('/index/admission_batch',{
			type: '专科',
			plan_type: '体育类'
	})
}

export const ans4 = () => {
	return request.post('/index/admission_batch',{
			type: '专科',
			plan_type: '三校生类'
	})
}


export const ans5 = () => {
	return request.post('/index/admission_batch',{
			type: '专科',
			plan_type: '普通类(历史)'
	})
}