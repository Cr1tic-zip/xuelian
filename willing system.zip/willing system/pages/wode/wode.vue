<template>
	<view class="body">
		<view class="user">
			<view class="touxiang">
				<image class="pic" src="../../static/wode/touxiang.jpg" mode="aspectFill"></image>
			</view>
			<view class="ip">192.168.31.205</view>
			<view class="shudi">ip属地: 山东</view>
		</view>
		<view class="section1">
			<view class="row">
				<view class="left"><uni-icons type="contact" size="50rpx" color="#1296db"></uni-icons><text class="text">个人资料</text></view>
				<view class="right"><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><uni-icons type="star" size="50rpx" color="#1296db"></uni-icons><text class="text">我的收藏</text></view>
				<view class="right"><view class="count">0</view><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><image src="../../static/wode/liulanjilu.png" class="icon"></image><text class="text">浏览记录</text></view>
				<view class="right"><view class="count">0</view><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><image src="../../static/wode/guanzhuxuexiao.png" class="icon"></image><text class="text">关注学校</text></view>
				<view class="right"><view class="count">0</view><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><uni-icons type="compose" size="50rpx" color="#1296db"></uni-icons><text class="text">关注专业</text></view>
				<view class="right"><view class="count">0</view><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><uni-icons type="chatboxes" size="50rpx" color="#1296db"></uni-icons><text class="text">联系客服</text></view>
				<view class="right"><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
		</view>
		<view class="placeholder">
			
		</view>
		<view class="section2">
			<view class="row">
				<view class="left"><uni-icons type="flag" size="50rpx" color="#1296db"></uni-icons><text class="text">常见问题</text></view>
				<view class="right"><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><uni-icons type="help" size="50rpx" color="#1296db"></uni-icons><text class="text">帮助</text></view>
				<view class="right"><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
			<view class="row">
				<view class="left"><uni-icons type="gear" size="50rpx" color="#1296db"></uni-icons><text class="text">设置</text></view>
				<view class="right"><uni-icons type="right" size="18" color="#aaa"></uni-icons></view>
			</view>
		</view>
	</view>
</template>

<script setup>
	
</script>

<style scoped>
	    .body {
			height: 90vh;
			width: 100vw;
			background: linear-gradient(to bottom,transparent,#fff 50%),linear-gradient(to right,aliceblue,lightblue);
			.user {
				height: 33%;
				width: 100%;
				display: flex;
				align-items: center;
				flex-direction: column;
				.touxiang {
					height: 70%;
					width: 100%;
					display: flex;
					align-items: center;
					justify-content: flex-end;
					flex-direction: column;
					box-sizing: border-box;
					.pic {
						height: 20vmin;
						width: 20vmin;
						border-radius: 50%;
					}
					
				}
				.ip {
					display: flex;
					align-items: center;
					height: 10%;
					box-sizing: border-box;
					margin: 3vmin 0;
					}
				.shudi {
					color: #aaa;
					margin-bottom: 10vmin;
				}
			}			
		}
		.section1 {
			height: 40%;
			width: 94%;
			margin: auto;
			display: flex;
			flex-direction: column;
			border: 1px solid #eee;
			border-radius: 10rpx;
			box-shadow: 0 0 30rpx rgba(0,0,0,0.05);
			.row {
				height: 20%;
				width: 92%;
				margin: 0 auto;
				display: flex;
				justify-content: space-between;
				align-items: center;;
				border-bottom: 1px solid #eee;
				&:last-child{ border-bottom: 0}
				.left {
					display: flex;
					align-items: center;
					.text {
						margin-left: 20rpx;
						color: #666;
					}
					.icon {
						width:  50rpx;
						height: 50rpx;
					}
				}
				.right {
					display: flex;
					align-items: center;
					.count {
						color: #aaa;
					}
				}
			}
		}
		
		.placeholder {
			height: 4%;
			width: 100%;
		}
		
		.section2 {
			height: 20%;
			width: 94%;
			margin: auto;
			display: flex;
			flex-direction: column;
			border: 1px solid #eee;
			border-radius: 10rpx;
			box-shadow: 0 0 30rpx rgba(0,0,0,0.05);
			.row {
				height: 40%;
				width: 92%;
				margin: 0 auto;
				display: flex;
				justify-content: space-between;
				align-items: center;;
				border-bottom: 1px solid #eee;
				&:last-child{ border-bottom: 0}
				.left {
					display: flex;
					align-items: center;
					.text {
						margin-left: 20rpx;
						color: #666;
					}
					.icon {
						width:  50rpx;
						height: 50rpx;
					}
				}
				.right {
					display: flex;
					align-items: center;
					.count {
						color: #aaa;
					}
				}
			}
		}
</style>
