c1r1() {
			  let url = 'https://www.gaokao.cn/school/108'  // URL是要跳转的外部地址 作为参数
			  uni.navigateTo({
				url: '../../pages/webview/webview?url=' + url
				// page.json定义的路径 传url 到webview界面去接收 实现跳转
			  })
		
			}