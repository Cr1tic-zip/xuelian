<template>
	<view class="body">
		<view class="sousuo">
			<uni-search-bar class="searchbar" @confirm="search" @input="input" maxlength="10"
							cancelButton="auto" @cancel="cancel" @clear="clear" clearButton="always" placeholder="查大学、查专业、搜问答">
			</uni-search-bar>
			<view class="qiehuan1"><picker @change="bindPickerChange" :value="index1" :range="array1" range-key="name">
						<view class="button">{{ array1[index1].name }}</view>
					</picker></view>
			<view type="button" class="qiehuan2"><picker @change="bindPickerChange" :value="index1" :range="array1" range-key="name">[切换]</picker></view>
		</view>
		<view class="lunbo">
			<swiper class="swiper" circular indicator-dots autoplay interval="3000" indicator-color="rgba(255,255,255,0.3)" indicator-active-color='white'>
				<swiper-item class="college"><image src="../../static/yanda.jpg" class="pic"></image></swiper-item>
				<swiper-item class="college"><image src="../../static/changhang.jpg" class="pic"></image></swiper-item>
				<swiper-item class="college"><image src="../../static/jiangcai.png" class="pic"></image></swiper-item>
				<swiper-item class="college"><image src="../../static/huajiao.jpg" class="pic"></image></swiper-item>
			</swiper>
		</view>
		<view class="gonggao">
			<view class="laba">
				<uni-icons type="sound-filled" color="#ffad7e" size="45rpx"></uni-icons>
			</view>
			<view class="redian">
				<text class="text">热点</text>
			</view>
			<view class="neirong">
				<swiper vertical autoplay circular interval="2000" duration="300">
					<swiper-item >江西2024高考本科批投档线出炉</swiper-item>
					<swiper-item >江西2024年高考本科提前批投档线（定向)</swiper-item>
					<swiper-item >江西2024年本科提前批（军事类平行志愿）投档线</swiper-item>
					<swiper-item >江西2024年高考本科提前批（非军事类单志愿）投档线</swiper-item>
				</swiper>
			</view>
			<view class="jiantou">
				<uni-icons type="forward" size="2vh"></uni-icons>
			</view>
		</view>
		<view class="remenyuanxiao">
			<view class="nav">
				<view class="heaven">热门院校</view>
				<view class="hell">更多 ></view>
			</view>
			<scroll-view class="scroll" scroll-x="true" @scroll="scroll" >
				<view class="lie">
					<view class="hang" @click="c1r1()">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/changda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">南昌大学</view>
							<view class="xia">
								<view class="text">江西</view>
								<view class="text">综合类</view>
								<view class="text">211</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/jiangli.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming" >
							<view class="shang">江西理工大学</view>
							<view class="xia">
								<view class="text">江西</view>
								<view class="text">理工类</view>
								<view class="text">公办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/jiuyuan.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">九江学院</view>
							<view class="xia">
								<view class="text">江西</view>
								<view class="text">综合类</view>
								<view class="text">公办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/changgong.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">南昌工学院</view>
							<view class="xia">
								<view class="text">江西</view>
								<view class="text">理工类</view>
								<view class="text">民办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
				</view>
				<view class="lie">
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zheda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">浙江大学</view>
							<view class="xia">
								<view class="text">浙江</view>
								<view class="text">综合类</view>
								<view class="text">985</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/ningda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">宁波大学</view>
							<view class="xia">
								<view class="text">浙江</view>
								<view class="text">综合类</view>
								<view class="text">双一流</view>
								<view class="text"></view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zhegongda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">浙江工业大学</view>
							<view class="xia">
								<view class="text">浙江</view>
								<view class="text">理工类</view>
								<view class="text">公办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/nuodinghan.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">宁波诺丁汉大学</view>
							<view class="xia">
								<view class="text">浙江</view>
								<view class="text">综合类</view>
								<view class="text">中外合作</view>
								<view class="text"></view>
							</view>
						</view>
					</view>
				</view>
				
				<view class="lie">
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/dongnan.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">东南大学</view>
							<view class="xia">
								<view class="text">江苏</view>
								<view class="text">综合类</view>
								<view class="text">985</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/suda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">苏州大学</view>
							<view class="xia">
								<view class="text">江苏</view>
								<view class="text">综合类</view>
								<view class="text">211</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/nanyou.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">南京邮电大学</view>
							<view class="xia">
								<view class="text">江苏</view>
								<view class="text">理工类</view>
								<view class="text">双一流</view>
								<view class="text"></view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/sanjiang.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">三江学院</view>
							<view class="xia">
								<view class="text">江苏</view>
								<view class="text">综合类</view>
								<view class="text">民办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
				</view>
				<view class="lie">
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zhengda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">郑州大学</view>
							<view class="xia">
								<view class="text">河南</view>
								<view class="text">综合类</view>
								<view class="text">211</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/heda.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">河南大学</view>
							<view class="xia">
								<view class="text">河南</view>
								<view class="text">综合类</view>
								<view class="text">双一流</view>
								<view class="text"></view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zhongyuan.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">中原科技学院</view>
							<view class="xia">
								<view class="text">河南</view>
								<view class="text">师范类</view>
								<view class="text">民办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/kaifeng.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">开封大学</view>
							<view class="xia">
								<view class="text">河南</view>
								<view class="text">综合类</view>
								<view class="text">公办</view>
								<view class="text">专科</view>
							</view>
						</view>
					</view>
				</view>
				<view class="lie">
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zhonghaiyang.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">中国海洋大学</view>
							<view class="xia">
								<view class="text">山东</view>
								<view class="text">综合类</view>
								<view class="text">985</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/zhongshiyou.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">中国石油大学(华东)</view>
							<view class="xia">
								<view class="text">山东</view>
								<view class="text">理工类</view>
								<view class="text">211</view>
								<view class="text">双一流</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/jida.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">济南大学</view>
							<view class="xia">
								<view class="text">山东</view>
								<view class="text">综合类</view>
								<view class="text">公办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
					<view class="hang">
						<view class="frontpic">
							<image src="../../static/shouye/remenyuanxiao/taishan.jpg" class="xiaohui" mode="aspectFill"></image>
						</view>
						<view class="xiaoming">
							<view class="shang">泰山科技学院</view>
							<view class="xia">
								<view class="text">山东</view>
								<view class="text">理工类</view>
								<view class="text">民办</view>
								<view class="text">本科</view>
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
		
		<view class="remenzhuanye">
			<view class="nav1">
				<view class="nav">
					<view class="heaven">热门专业</view>
					<view class="hell">更多 ></view>
				</view>
			</view>	
			<view class="content">
				<view class="row1">
					<view class="pic1">
						<view class="above">计算机类</view>
						<image src="../../static/shouye/jisuanjilei.png" class="jisuanji"></image>
					</view>
					<view class="pic1">
						<view class="above">金融类</view>
						<image src="../../static/shouye/jinrong.png" class="jisuanji"></image>
					</view>
				</view>
				<view class="row1">
					<view class="pic1">
						<view class="above">医学类</view>
						<image src="../../static/shouye/yixue.png" class="jisuanji"></image>
					</view>
					<view class="pic1">
						<view class="above">师范类</view>
						<image src="../../static/shouye/shifan.png" class="jisuanji"></image>
					</view>
				</view>
			</view>
		</view>
		
		<view class="zixun">
			<view class="inner">
				<view class="nav">
					<view class="heaven">热门咨询</view>
					<view class="hell">更多 ></view>
				</view>
				<view class="pai">
					<view class="hover">江西建设职业技术学院2024年招生简章</view>
					<view class="below">
						<view class="place">
							<view class="helll"><image src="../../static/shouye/time.png" class="picture"></image>6月25日</view>
						    <view class="helll"><uni-icons type="eye" size="42rpx"></uni-icons>1.1万</view>
						</view>
					</view>
				</view>
				<view class="pai">
					<view class="hover">这些大学，今年不招生！</view>
					<view class="below">
						<view class="place">
							<view class="helll"><image src="../../static/shouye/time.png" class="picture"></image>7月5日</view>
						    <view class="helll"><uni-icons type="eye" size="42rpx"></uni-icons>7862</view>
						</view>
					</view>
				</view>
				<view class="pai">
					<view class="hover">两所新大学，揭牌！</view>
					<view class="below">
						<view class="place">
							<view class="helll"><image src="../../static/shouye/time.png" class="picture"></image>7月18日</view>
						    <view class="helll"><uni-icons type="eye" size="42rpx"></uni-icons>1.5万</view>
						</view>
					</view>
				</view>
				<view class="pai">
					<view class="hover">首届强基生，现在怎么样了？</view>
					<view class="below">
						<view class="place">
							<view class="helll"><image src="../../static/shouye/time.png" class="picture"></image>7月25日</view>
						    <view class="helll"><uni-icons type="eye" size="42rpx"></uni-icons>1246</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="ph"></view>
	</view>
</template>

<script setup>
	export default {
	    data() {
	        return {
	            array1: [
						{ name: '北京' },  
					    { name: '天津' },  
					    { name: '河北' },  
					    { name: '山西' },  
					    { name: '内蒙古' },  
					    { name: '辽宁' },  
					    { name: '吉林' },  
					    { name: '黑龙江' },  
					    { name: '江苏' },  
					    { name: '浙江' },  
					    { name: '安徽' },  
					    { name: '福建' },  
					    { name: '江西' },  
					    { name: '山东' },  
					    { name: '河南' },  
					    { name: '湖北' },  
					    { name: '湖南' },  
					    { name: '广东' },  
					    { name: '广西' },  
					    { name: '海南' },  
					    { name: '重庆' },  
					    { name: '四川' },  
					    { name: '贵州' },  
					    { name: '云南' },  
					    { name: '西藏' },  
					    { name: '陕西' },  
					    { name: '甘肃' },  
					    { name: '青海' },  
					    { name: '宁夏' },  
					    { name: '新疆' },  
					],
	            index1: 12,
	        };
	    },
	    methods: {
	        bindPickerChange: function(e) {
	            this.index1 = e.detail.value;
	        },
			 // 触发跳转
	    }
	};
</script>

<style lang="scss" scoped>
	@import url("shouye.css");
</style>
