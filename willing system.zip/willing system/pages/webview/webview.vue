<template>
  <web-view :src="url"></web-view>
</template>

<script>
</script>

<style lang="scss">
</style>

