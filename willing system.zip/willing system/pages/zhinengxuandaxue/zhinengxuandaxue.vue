<template>
	<view class="body">
		<image class="bgp" src="../../static/xuandaxue.jpg"></image>
		<view class="title">智能选大学</view>
		<view class="content">
			<view class="spawn">
			    <view class="head">生源地</view>
			    <view class="back">	<picker @change="bindPickerChange" :value="index1" :range="array1" range-key="name">
						<view>{{ array1[index1].name }} ></view>
					</picker>
				</view>
			</view>
			<view class="select">
				<view class="title1">选择科目</view>
				<view class="button"> 
					<view class="list-box">
						<view v-for="(item,index) in list" :key="index" @click="choice(index)" :class="[item.selected?'selde':'noselde']">
							{{item.selected?item.title:item.title}}
						</view>
					</view>
                </view>
				<view class="title2">
				    <view class="front">考试分数</view>
					<view class="behind2">
						<input class="input" placeholder="请输入您的分数" maxlength="4"/>
					</view>
				</view>
				<view class="title3">
					<view class="front">考试位次</view>
					<view class="behind2">
						<input class="input" placeholder="请输入您的分数" maxlength="7"/>
					</view>
				</view>
				<view class="bottom">选大学</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	export default {
	    data() {
	        return {
	            array1: [
						{ name: '北京' },  
					    { name: '天津' },  
					    { name: '河北' },  
					    { name: '山西' },  
					    { name: '内蒙古' },  
					    { name: '辽宁' },  
					    { name: '吉林' },  
					    { name: '黑龙江' },  
					    { name: '江苏' },  
					    { name: '浙江' },  
					    { name: '安徽' },  
					    { name: '福建' },  
					    { name: '江西' },  
					    { name: '山东' },  
					    { name: '河南' },  
					    { name: '湖北' },  
					    { name: '湖南' },  
					    { name: '广东' },  
					    { name: '广西' },  
					    { name: '海南' },  
					    { name: '重庆' },  
					    { name: '四川' },  
					    { name: '贵州' },  
					    { name: '云南' },  
					    { name: '西藏' },  
					    { name: '陕西' },  
					    { name: '甘肃' },  
					    { name: '青海' },  
					    { name: '宁夏' },  
					    { name: '新疆' },  
					],
					array2: [
						{ name: '普通类'},
						{ name: '艺术类(未开放)'},
					],
	            index1: 0,
				selectedCount: 0,
				selectList:"",
				//给标签赋值
				list: [
					{ selected: false,title: '物理' },
					{ selected: false,title: '化学' },
					{ selected: false,title: '生物' },
					{ selected: false,title: '政治' },
					{ selected: false,title: '历史' }, 
					{ selected: false,title: '地理' } ,
					],
	        };
	    },
		
	    methods: { 
	        bindPickerChange: function(e) {
	            this.index1 = e.detail.value;
	        },
			
			  choice(index) {  
			            if (this.list[index].selected) {  
			                // 如果已经选中，则取消选中  
			                this.list[index].selected = false;  
			                this.selectedCount--; // 减少已选择科目的计数  
			            } else {  
			                // 检查是否已经达到了三个选择的上限  
			                if (this.selectedCount < 3) {  
			                    this.list[index].selected = true;  
			                    this.selectedCount++; // 增加已选择科目的计数  
			                } else {  
			                    // 如果已经达到了上限，则不执行任何操作或给出提示  
			                    alert('您最多只能选择三个科目！');  
			                }  
			            }  
			            // 这里不需要单独的变量来存储 selectId，但如果你需要它，可以这样计算  
			            // const selectId = this.list.filter(item => item.selected).map(item => item.title);  
			    }  
	    }
	};
</script>

<style lang="scss" scoped>
	.body {
		height: 94vh;
		width: 100vw;
		background: linear-gradient(to bottom,transparent,#fff 50%),linear-gradient(to right,#fff2e1,#ffedde);
	}
	
	.bgp {
		width: 100%;
		height: 20%;
		z-index: 0;
	}
	
	.title {
		width: 90%;
		height: 200rpx;
		top: 80rpx;
		left: 80rpx;
		z-index: 999;
		position: absolute;
		font-size: 70rpx;
		font-family: 华文琥珀;
		color : #ffb245;
	}
	
	.content {
		width: 92%;
		height: 1100rpx;
		margin: 15rpx auto;
		border-radius: 20rpx;
		border: 1px solid #eee;
		box-shadow: 0 0 30rpx rgba(0,0,0,0.05);
		background-color: white;
		.row {
			width: 94% ;
			height: 80rpx;
			margin: 20rpx auto;
			display: flex;
			.front {
				width: 80%;
				height: 100%;
				display: flex;
				align-items: center;
				font-size: 40rpx;
				font-weight: 500;
			}
		}
	}
	
	.title1 {
		width: 90%;
		height: 80rpx;
		margin: 20rpx auto;
		display: flex;
		align-items: center;
		font-size: 40rpx;
		font-weight: bold;
		color: #555555;
	}
	
	.title2 {
		width: 90%;
		height: 90rpx;
		margin: 100rpx auto 50rpx auto;
		display: flex;
		border-bottom: 1px solid #9b9b9b;
		align-items: center;
		justify-content: space-between;
		font-size: 40rpx;
		font-weight: bold;
		color: #555555;
	}
	
	.title3 {
		width: 90%;
		height: 80rpx;
		margin: 0 auto;
		display: flex;
		align-items: center;
		font-size: 40rpx;
		font-weight: bold;
		justify-content: space-between;
		color: #555555;
		border-bottom: 1px solid #9b9b9b;
	}
	
	.bottom {
		width: 90%;
		height: 100rpx;
		margin: 40rpx auto;
		border-radius: 20rpx;
		display: flex;
		justify-content: center;align-items: center;
		font-weight: 550;
		font-size: 40rpx;
		color: #fff;
		background-color: #ff9c5a;
	}
	
	.behind2 {
		height: 100%;
		width: 300rpx;
		padding: 10rpx 0 0 20rpx;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		justify-content: flex-end;
		
	}
	
	.input {
		text-align: right;
		font-size: 30rpx;
		font-weight: 500;
	}
	
	.spawn {
		width: 90%;
		height: 120rpx;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1px solid #9b9b9b;
		.head {
			font-size: 35rpx;
			font-weight: bold;
		}
		.back {
			color: #9b9b9b;
			font-size: 30rpx;
		}
	}
	
	.button {
		width: 90%;
		height: 200rpx;
		margin: 20rpx auto;
	}
	
	.list-box {
	        display: flex;
	        flex-wrap: wrap;
	        border-radius: 10upx;
			justify-content: space-between;
	
	        view {
	            width: 25%;
	            height: 80rpx;
				margin: 20rpx 0;
	            display: flex;
				align-items: center;
				justify-content: center;
				font-size: 30rpx;
	        }
	    }
	
	    /* 已选择 */
	    .selde {
	        background: darkorange;
	        color: #FFFFFF;
	        border-radius: 20upx;
	        font-size: 20upx;
	        padding: 0 10upx;
	    }
	
	    /* 未选择 */
	    .noselde {
	        border: 1px solid #959595;
	        background: #FFFFFF;
	        color: #959595;
	        border-radius: 20upx;
	        font-size: 20upx;
	        padding: 0 10upx;
	    }
</style>
