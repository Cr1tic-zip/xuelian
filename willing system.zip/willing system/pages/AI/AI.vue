<template>
	<view class="body" id="app">
		<image src="https://xueliannet.com/img/pic-01.c0691864.png" class="background"></image>
		<view class="swipercontainer">
			<swiper class="swiper" circular indicator-dots="indicatorDots" autoplay="autoplay" 
			interval="3000" duration="500">
				<swiper-item class="swiper-item">
					<a href="https://v.xiumi.us/stage/v5/3qeqY/545322292">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240517/1c90f183d96dcccb29ff927711ae5c1b.jpg"></image>
					</a>
				</swiper-item>
				<swiper-item>
					<a href="https://mp.weixin.qq.com/s/j4o087qlDflYnXVtIt2QOA">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240130/fc515c991b74c04237629aa96c19aaa7.jpg"></image>
					</a>
				</swiper-item>
				<swiper-item>
					<a href="https://mp.weixin.qq.com/s/iIN6nuRfPmm9V0m44bdZdg">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240517/6f4e78a8d128f90b5ad0a54a25c62888.jpg"></image>
					</a>
				</swiper-item>
				<swiper-item>
					<a href="https://mp.weixin.qq.com/s/sMe4WO4nCXiZoZl3mPKnNA">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240130/2374766b25f453c8ab8b9fbabe360a4d.jpg"></image>
					</a>
				</swiper-item>
				<swiper-item>
					<a href="https://mp.weixin.qq.com/s/tgvQpbsJunKKBCLNn-X1ww">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240130/4f8bf4f0c60f403912c7907fa0ebfb4f.jpg"></image>
					</a>
				</swiper-item>
				<swiper-item>
					<a href="https://mp.weixin.qq.com/s/8Ql9LRBPRz-C9-OBPGWs0g">
						<image class="swiperpic" src="https://xueliannet.com/uploads/20240629/a08c302486981dd82313f6c901f15478.jpg"></image>
					</a>
				</swiper-item>
			</swiper>
		</view>
		<view class="noticectn">
			<view class="notice">
				<view class="noticehead">
					<view class="above">我的大学我做主</view>
					<view class="hell">——历年分数位次专业组适配——</view>
				</view>
				<view class="astruction">
					<view class="headertext">
						模拟报考说明
					</view>
					<view class="row">
						<view class="rowpiccan"><image src="@/static/ai/row1.png" class="rowpic"></image></view>
						<view class="rowtext">应用AI智能推荐算法和大数据技术，结合全国高校历年真实投档录取数据</view>
					</view>
					<view class="row">
						<view class="rowpiccan"><image src="@/static/ai/row2.png" class="rowpic"></image></view>
						<view class="rowtext">根据考生当年高考成绩及位次信息，精准匹配考生选科所对应的院校专业组</view>
					</view>
					<view class="row">
						<view class="rowpiccan"><image src="@/static/ai/row3.png" class="rowpic"></image></view>
						<view class="rowtext">模拟推荐智能按“冲刺、稳妥、保底”形成合理的梯度，有效降低填报风险</view>
					</view>
					<view class="row">
						<view class="rowpiccan"><image src="@/static/ai/row4.png" class="rowpic"></image></view>
						<view class="rowtext">新高考志愿填报AI辅助系统推荐的院校，仅为志愿参考，不作为填报依据</view>
					</view>
				</view>
			</view>
			<view class="funcarea">
				<view class="header">
					<view class="scorepicker" :class="{active :current === 0}" @click="current = 0,scorechange(),clear()">分数模拟</view>
					<view class="rankpicker" :class="{active :current === 1}" @click="current = 1,scorechange(),clear()">位次模拟</view>
				</view>
				<view class="buttons">
					<view class="button1" :class="{activebutton :button===0}" @click="button = 0,objectchange(),clear()">本科</view>
					<view class="button2" :class="{activebutton :button===1}" @click="button = 1,objectchange(),clear()">专科</view>
				</view>
				<view class="search">
					<image src="../../static/ai/search.png" class="searchpic"></image>
					<input id="input" v-model="inputvalue" class="searchput" :placeholder="placeholdertext()" :maxlength="lengthcal()"/>
				</view>
				<view class="selector1">
					<view class="text">选考科目:</view>
					
					<picker @change="bindPickerChange" :value="index" :range="array" range-key="name">
						<view class="firstobject">
							<view class="uni-input">{{array[index].name}}</view>
							<image src="../../static/ai/icon.png" class="icon"/>
						</view>		
					</picker>
						
					<view class="otherobject">
						<view class="button" :class="{statuse :status === 1}" @click="toggle('bottom')">
							{{result}}
							<image src="../../static/ai/icon.png" class="icon"/>
					    </view>
						<uni-popup ref="popup" background-color="#fff">
							<view class="popup-content">
								<view class="row1">
									<view class="cancel" @click="close" >取消</view>
									<view class="title">再选科目</view>
									<view class="confirm" @click="close">确定</view>
								</view>
								<view class="togglerow">
									<view class="reobject" :class="{activebutton :selected1 === 1}"  @click="select1()">化学</view>
									<view class="reobject" :class="{activebutton :selected2 === 1}"  @click="select2()">生物</view>
									<view class="reobject" :class="{activebutton :selected3 === 1}"  @click="select3()">政治</view>
									<view class="reobject" :class="{activebutton :selected4 === 1}"  @click="select4()">地理</view>
								</view>
							</view>
						</uni-popup>
					</view>
				</view>
				<view class="selector1">
					<view class="text">报考类别:</view>
					<picker @change="typeschange" :value="typeindex" :range="plantype()" range-key="name" class="typepicker">
						<view class="singlecheck">
							<view class="uni-input">{{plantype()[typeindex].name}}</view>
							<image src="../../static/ai/icon.png" class="icon"/>
						</view>		
					</picker>
				</view>
				<view class="selector1">
					<view class="text">录取批次:</view>
					<picker @change="batchchange" :value="batchindex" :range="batch" class="batchpicker">
						<view class="singlecheck">
							<view class="uni-input">{{batch[batchindex]}}</view>
							<image src="../../static/ai/icon.png" class="icon"/>
						</view>		
					</picker>
				</view>
				<view class="selector1">
					<view class="text">意向区域:</view>
					<view class="singlecheck"  @click="areatoggle('bottom')">
						<view class="arealist" :class="{willing :this.selectedareas.length === 0}">{{displayareas}}</view>
						<view class="beneath">可单选<br>可多选<image src="../../static/ai/icon.png" class="icon" /></view>
					</view>
					<uni-popup ref="area" background-color="#fff">
						<view class="popup-content-area">
							<view class="row2">
								<view class="cancel" @click="closearea" >取消</view>
								<view class="title">意向区域</view>
								<view class="confirm" @click="closearea">确定</view>
							</view>
							<view class="togglerow">
								<view class="edgeobject"  :key="item.index" :class="{activebutton :selectedareas.some(test => test === item)}"
								 @click="addareas(item)" v-for="item in provinces_list">{{item}}</view>
							</view>
						</view>
					</uni-popup>
				</view>
				<view class="simulate" @click="simulate">模拟</view>
			</view>
			<view class="result">
				<view class="result-header">
					
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import axios from 'axios'
	import {proviceListApi,res1,res2,res3,res4,res5,ans1,ans3,ans4,ans5} from '@/api/home.js'
	import { judge,showareas,addarea,select1,select2,select3,select4,objectchange,batch } from '@/common/js/function.js'
	export default {
		data() {
			return {
				array: [
					{name: '物理'},
					{name: '历史'}
				],
				physicstype: [
					{name: '普通类(物理)'},
					{name: '艺术类'},
					{name: '体育类'},
					{name: '三校生类'}
				],
				historytype: [
					{name: '普通类(历史)'},
					{name: '艺术类'},
					{name: '体育类'},
					{name: '三校生类'}
				],
				current: 0,
				button: 0,
				selected1: 0, selected2: 0, selected3: 0, selected4: 0,
				selectedcount: 0,
				status: 0,
				selectarea: 0,
				objects: [],
				selectedareas: ["全国"],	
				provinces_list: [],
				object: "本科",
				sorrank: "分数",
				inputvalue: "",
				index: 0,
				typeindex: 0,
				batchindex: 0,
				type: 'center',
				area: 'center',
				ug_batch_phy_01: [], ug_batch_phy_02: [], ug_batch_phy_03: [], ug_batch_phy_04: [],
				ug_batch_his_01: [],
				sk_batch_phy_01: [], sk_batch_phy_02: [], sk_batch_phy_03: [], sk_batch_phy_04: [],
				sk_batch_his_01: [], sk_batch_his_02: [], sk_batch_his_03: [], sk_batch_his_04: []
			}
		},
		
		async mounted(){
			proviceListApi().then(res => this.provinces_list = res.data)
			
			res1().then(res => this.ug_batch_phy_01 = res.data )
			
			res2().then(res => {this.ug_batch_phy_02 = res.data; this.sk_batch_phy_02 = res.data})
			
			res3().then(res => this.ug_batch_phy_03 = res.data )
			
			res4().then(res => this.ug_batch_phy_04 = res.data )
			
			res5().then(res => this.ug_batch_his_01 = res.data )
			
			ans1().then(res => this.sk_batch_phy_01 = res.data )
			
			ans3().then(res => this.sk_batch_phy_03 = res.data )
			
			ans4().then(res => {this.sk_batch_phy_04 = res.data;this.sk_batch_his_02 = res.data} )
			
			ans5().then(res => this.sk_batch_his_01 = res.data )
			},
		 computed: {  
		    result() {  
				return judge.call(this); // 注意这里使用 call 来绑定 this  
		    },  
			
			batch() {
				return batch.call(this)
			},
			
			displayareas() {
				return showareas.call(this)
			},
		  },  
		methods: {
			addareas(item) {  
					addarea.call(this, item);  
			    },  
			
			select1() {
				select1.call(this)
			},
			
			select2() {
				select2.call(this)
			},
			
			select3() {
				select3.call(this)
			},
			
			select4() {
				select4.call(this)
			},
			
			closearea() {
						this.$refs.area.close()
					},
					
			close() {
						this.$refs.popup.close()
					},
							
					
			open() {
						this.$refs.popup.open('top')
					},
			
			areaopen() {
						this.$refs.area.open('top')
					},
			
			toggle(type) {
							this.type = type
							// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
							this.$refs.popup.open(type)
						},
			
			areatoggle(type) {
							this.area = type
							// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
							this.$refs.area.open(type)
						},
			
			placeholdertext(){
				if(this.current === 0) {
					return `请输入${this.object}分数`;
				} else {
					return `请输入高考${this.object}位次`;
				}
			},
			
			objectchange() {
				objectchange.call(this)
			},
			
			clear(){
				this.inputvalue = ""
			},
			
			scorechange(){
				if(this.current===1)
				{
					this.sorrank = "位次"
				}
				else {
					this.sorrank = "分数"
				}
			},
			
			plantype(){
				if(this.index === 0){
					return this.physicstype
				}
				else {
					return this.historytype
				}
			},
			
			lengthcal(){
				if(this.current === 0){
					return 4
				}
				else {
					return 7
				}
			},
			
			bindPickerChange: function(e)
			{
				// const result = await axios.post('/test/api.php/index/plan_type')
				// console.log('result', result)
				this.index = e.detail.value;
				this.typeindex = 0
				this.batchindex = 0
			},
			
			typeschange: function(e){
				// const result = await axios.post('/test/api.php/index/plan_type')
				// console.log('result', result)
				this.typeindex = e.detail.value;
				this.batchindex = 0
			},
			
			batchchange: function(e){
				// const result = await axios.post('/test/api.php/index/plan_type')
				// console.log('result', result)
				this.batchindex = e.detail.value;
			},
		}
	}
</script>

<style>
    @import url(ai.css);
</style>
