<template>
	<view class="body">
		<image src="../../static/zhiyuantianbao.jpg" class="bgp"></image>
		<view class="content">
			<view class="row">
				<view class="front">高考省份</view>
				<view class="behind">
					<picker @change="bindPickerChange" :value="index1" :range="array1" range-key="name">
						<view class="button">{{ array1[index1].name }}</view>
					</picker>
					<uni-icons type="right" size="30rpx"></uni-icons>
				</view>
			</view>
			<view class="row1">
				<view class="front">考生类型</view>
				<view class="behind">
					<picker @change="bindPickerChange2" :value="index2" :range="array2" range-key="name">
						<view class="button">{{ array2[index2].name }}</view>
					</picker>
					<uni-icons type="right" size="30rpx"></uni-icons>
				</view>
			</view>
			<view class="row1">
				<view class="front">高考科目</view>
				<view class="behind">
					<picker  :value="index2" :range="list" range-key="name">
						<view class="list-box">
							<view v-for="(item,index) in list" :key="index" @click="choice(index)" :class="[item.selected?'selde':'noselde']">
								<view class="valueList">
									{{selectList}}
								</view>
							</view>
						</view>
					</picker>
					<uni-icons type="right" size="30rpx"></uni-icons>
				</view>
			</view>
			<view class="row1">
				<view class="front">高考分数</view>
				<view class="behind2">
					<input class="input" placeholder="请输入您的分数" maxlength="4"/>
				</view>
			</view>
			<view class="row1">
				<view class="front">高考位次</view>
				<view class="behind2">
					<input class="input" placeholder="请输入您的位次" maxlength="7"/>
				</view>
			</view>
			<view class="row1">
				<view class="tianbutton">
					开始填报
				</view>
			</view>
			<view class="row1">
				<view class="tianbutton2">
					一键智能填报
				</view>
			</view>
			<view class="row2">
				<view class="part">
					<view class="inner">
						<image class="iconfont" src="../../static/monizhiyuan/zhiyuanbiao.png"></image>
						<view class="text">志愿表</view>
					</view>
				</view>
				<view class="part">
					<view class="inner">
						<image class="iconfont1" src="../../static/monizhiyuan/dingdan.png"></image>
						<view class="text">我的订单</view>
					</view>
				</view>
				<view class="part">
					<view class="inner">
						<image class="iconfont2" src="../../static/monizhiyuan/huiyuan.png"></image>
						<view class="text">会员中心</view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="last">
			<view class="attention">注意:  系统只提供志愿填报辅助功能，正式填报请前往教育考试院官网</view>
		</view>
	</view>
</template>

<script>
		export default {
		    data() {
		        return {
		            array1: [
							{ name: '北京' },  
						    { name: '天津' },  
						    { name: '河北' },  
						    { name: '山西' },  
						    { name: '内蒙古' },  
						    { name: '辽宁' },  
						    { name: '吉林' },  
						    { name: '黑龙江' },  
						    { name: '江苏' },  
						    { name: '浙江' },  
						    { name: '安徽' },  
						    { name: '福建' },  
						    { name: '江西' },  
						    { name: '山东' },  
						    { name: '河南' },  
						    { name: '湖北' },  
						    { name: '湖南' },  
						    { name: '广东' },  
						    { name: '广西' },  
						    { name: '海南' },  
						    { name: '重庆' },  
						    { name: '四川' },  
						    { name: '贵州' },  
						    { name: '云南' },  
						    { name: '西藏' },  
						    { name: '陕西' },  
						    { name: '甘肃' },  
						    { name: '青海' },  
						    { name: '宁夏' },  
						    { name: '新疆' },  
						],
						array2: [
							{ name: '普通类'},
							{ name: '艺术类(未开放)'},
						],
		            index1: 0,
					index2: 0,
					selectedCount: 0,
					selectList:"",
					//给标签赋值
					list: [
						{ selected: false,title: '物理' },
						{ selected: false,title: '化学' },
						{ selected: false,title: '生物' },
						{ selected: false,title: '政治' },
						{ selected: false,title: '历史' }, 
						{ selected: false,title: '地理' } ,
						],
		        };
		    },
		    methods: {
		        bindPickerChange: function(e) {
		            this.index1 = e.detail.value;
		        },
				bindPickerChange2: function(e) {
				    this.index2 = e.detail.value;
				},
				choice(index) {
					            if (this.list[index].selected) {  
					                // 如果已经选中，则取消选中  
					                this.list[index].selected = false;  
					                this.selectedCount--; // 减少已选择科目的计数  
					            } else {  
					                // 检查是否已经达到了三个选择的上限  
					                if (this.selectedCount < 3) {  
					                    this.list[index].selected = true;  
					                    this.selectedCount++; // 增加已选择科目的计数  
					                } else {  
					                    // 如果已经达到了上限，则不执行任何操作或给出提示  
					                }  
					            }  
					            // 这里不需要单独的变量来存储 selectId，但如果你需要它，可以这样计算  
					            // const selectId = this.list.filter(item => item.selected).map(item => item.title);  
					    }  
				}
		    
		};
</script>

<style lang="scss" scoped>
	.body {
		height: 1500rpx;
		width: 100vw;
		background: linear-gradient(to bottom,transparent,#fff 50%),linear-gradient(to right,aliceblue,lightblue);
	}
	
	.bgp {
		height: 20%;
		width: 100%;
	}
	
	.content {
		width: 92%;
		height: 1100rpx;
		margin: 15rpx auto;
		border-radius: 20rpx;
		border: 1px solid #eee;
		box-shadow: 0 0 30rpx rgba(0,0,0,0.05);
		background-color: white;
		.row {
			width: 94% ;
			height: 80rpx;
			margin: 20rpx auto;
			display: flex;
			.front {
				width: 80%;
				height: 100%;
				display: flex;
				align-items: center;
				font-size: 40rpx;
				font-weight: 500;
			}
		}
	}
	
	.row1 {
		width: 94% ;
		height: 80rpx;
		margin: 60rpx auto;
		display: flex;
		.front {
			width: 80%;
			height: 100%;
			display: flex;
			align-items: center;
			font-size: 40rpx;
			font-weight: 500;
		}
	}
	
	.behind {
		height: 100%;
		width: 400rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		picker {
			display: flex;
			align-items: center;
			justify-content: flex-end;
			height: 100%;
			width: 360rpx;
		}
	}
	
	.behind2 {
		height: 100%;
		width: 300rpx;
		padding: 10rpx 0 0 20rpx;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		justify-content: flex-end;
		
	}
	
	.button {
		display: flex;
		margin: auto 10rpx;
		height: 100%;
		font-size: 35rpx;
		font-weight: 500;
	}
	
	.tianbutton {
		width: 100%;
		height: 110rpx;
		border-radius: 20rpx;
		background: linear-gradient(to right,rgba(44,114,251,1),rgb(113,65,168)	);
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 40rpx;
		font-weight: 500;
		color: whitesmoke;
	}
	
	.tianbutton2 {
		width: 100%;
		height: 110rpx;
		border-radius: 20rpx;
		background-color: lightblue;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 40rpx;
		font-weight: 500;
		color: rgb(136, 115, 168);
	}
	
	.row2 {
		width: 94% ;
		height: 80rpx;
		margin: 60rpx auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
		.part {
			height: 90rpx;
			width: 210rpx;
			border-radius: 20rpx;
			background-color: #fff9ed;
			display: flex;
			justify-content: center;
			align-items: center;
			.inner {
				width: 200rpx;
				height: 64rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				.iconfont {
				height: 40rpx;
				width: 40rpx;
			    }
				.text {
					font-size: 35rpx;
					font-weight: bold;
					margin-left: 10rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}
			}
		}
	}
	
	.iconfont1 {
	height: 45rpx;
	width: 45rpx;
	margin-right: -6rpx;
	}
	
	.iconfont2 {
	height: 50rpx;
	width: 50rpx;
	margin-right: -10rpx;
	}
	
	.input {
		text-align: right;
	}
	
	.last {
		width: 90%;
		margin: 30rpx auto;
		.attention {
			color: #9c9c9c;
			font-size: 30rpx;
		}
	}
</style>
