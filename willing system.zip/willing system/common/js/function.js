export function judge(){
			if(this.selected1 === 1||this.selected2 === 1||this.selected3 === 1||this.selected4 === 1){
				this.status = 1
				if(this.objects[1] === undefined){
					return this.objects[0]
				}
				else if(this.objects[0] === undefined){
					return this.objects[1]
				} 
				else if(this.objects[1] === "化学"){
					return this.objects[1] + "、" + this.objects[0]
				}
				else if(this.objects[0] === "地理"){
					return this.objects[1] + "、" + this.objects[0]
				}
				else if(this.objects[0] === "政治"&&this.objects[1] === "生物"){
					return this.objects[1] + "、" + this.objects[0]
				}
				else {
					return this.objects[0] + "、" + this.objects[1]
				}
			}
			else{
				this.status = 0
				return "再选科目"
			}
		}
		
export function showareas(){
				if(this.selectedareas.length >= 1){
					let result = this.selectedareas[0]
					for( let i = 1 ; i < this.selectedareas.length ;i ++){
						result  =  result + "、" + this.selectedareas[i]  
					}
					return result
				}
				else{
					return "请选择意向区域"
				}
			}
			
export function addarea(item){
				if(!this.selectedareas.includes("全国")&&item === "全国"){
					this.selectedareas.splice(item)
				}
				if(!this.selectedareas.includes(item)&&this.selectedareas.includes("全国")){
					this.selectedareas.splice(0)
					this.selectedareas.push(item)
					this.selectarea = 1
				}
				else if(!this.selectedareas.includes(item)){
					this.selectedareas.push(item)
					this.selectarea = 1
				}
				else{
					let seeker = this.selectedareas.filter(function(element){
						return element !== item
					})
					this.selectedareas = seeker
				}
			}
			
export function select1() {
				if(this.selected1 === 0&&this.selectedcount < 2){
					this.selected1 = 1
					this.selectedcount++
					if(this.objects[0] === undefined){
						this.objects[0] = "化学"
					}
					else if(this.objects[0] != undefined&&this.objects[1] === undefined){
							this.objects[1] = "化学"
						}
				}
				
				else if(this.selected1 === 1&&this.selectedcount === 2){
					this.selected1 = 0
					this.selectedcount--
					if(this.objects[0] === "化学"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "化学"){
						this.objects[1] = undefined
					}
				}
				
				else if(this.selectedcount === 2){
					this.selected1 = 1 
					this.selectedcount =2
					if(this.objects[0] === "生物"){
						this.selected2 = 0
					}
					else if(this.objects[0] === "政治"){
						this.selected3 = 0
					}
					else if(this.objects[0] === "地理"){
						this.selected4 = 0
					}
					this.objects[0] = this.objects[1]
					this.objects[1] = "化学"
				}
				
				else if(this.selected1 === 1){
					this.selected1 = 0
					this.selectedcount--
					if(this.objects[0] === "化学"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "化学"){
						this.objects[1] = undefined
					}
				}
			}
			
export function select2() {
				if(this.selected2 === 0&&this.selectedcount < 2){
					this.selected2 = 1
					this.selectedcount++
					if(this.objects[0] === undefined){
						this.objects[0] = "生物"
					}
					else if(this.objects[0] != undefined&&this.objects[1] === undefined){
							this.objects[1] = "生物"
						}
				}
				
				else if(this.selected2 === 1&&this.selectedcount === 2){
					this.selected2 = 0
					this.selectedcount--
					if(this.objects[0] === "生物"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "生物"){
						this.objects[1] = undefined
					}
				}
				
				else if(this.selectedcount === 2){
					this.selected2 = 1 
					this.selectedcount =2
					if(this.objects[0] === "化学"){
						this.selected1 = 0
					}
					else if(this.objects[0] === "政治"){
						this.selected3 = 0
					}
					else if(this.objects[0] === "地理"){
						this.selected4 = 0
					}
					this.objects[0] = this.objects[1]
					this.objects[1] = "生物"
				}
				
				else if(this.selected2 === 1){
					this.selected2 = 0
					this.selectedcount--
					if(this.objects[0] === "生物"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "生物"){
						this.objects[1] = undefined
					}
				}
				
			}
			
export function select3() {
				if(this.selected3 === 0&&this.selectedcount < 2){
					this.selected3 = 1
					this.selectedcount++
					if(this.objects[0] === undefined){
						this.objects[0] = "政治"
					}
					else if(this.objects[0] != undefined&&this.objects[1] === undefined){
							this.objects[1] = "政治"
						}
				}
				
				else if(this.selected3 === 1&&this.selectedcount === 2){
					this.selected3 = 0
					this.selectedcount--
					if(this.objects[0] === "政治"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "政治"){
						this.objects[1] = undefined
					}
				}
				
				else if(this.selectedcount === 2){
					this.selected3 = 1 
					this.selectedcount =2
					if(this.objects[0] === "化学"){
						this.selected1 = 0
					}
					else if(this.objects[0] === "生物"){
						this.selected2 = 0
					}
					else if(this.objects[0] === "地理"){
						this.selected4 = 0
					}
					this.objects[0] = this.objects[1]
					this.objects[1] = "政治"
				}
				
				else if(this.selected3 === 1){
					this.selected3 = 0
					this.selectedcount--
					if(this.objects[0] === "政治"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "政治"){
						this.objects[1] = undefined
					}
				}
				
			}
			
export function select4() {
				if(this.selected4 === 0&&this.selectedcount < 2){
					this.selected4 = 1
					this.selectedcount++
					if(this.objects[0] === undefined){
						this.objects[0] = "地理"
					}
					else if(this.objects[0] != undefined&&this.objects[1] === undefined){
							this.objects[1] = "地理"
						}
				}
				
				else if(this.selected4 === 1&&this.selectedcount === 2){
					this.selected4 = 0
					this.selectedcount--
					if(this.objects[0] === "地理"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "地理"){
						this.objects[1] = undefined
					}
				}
				
				else if(this.selectedcount === 2){
					this.selected4 = 1 
					this.selectedcount =2
					if(this.objects[0] === "化学"){
						this.selected1 = 0
					}
					else if(this.objects[0] === "生物"){
						this.selected2 = 0
					}
					else if(this.objects[0] === "政治"){
						this.selected3 = 0
					}
					this.objects[0] = this.objects[1]
					this.objects[1] = "地理"
				}
				
				else if(this.selected4 === 1){
					this.selected4 = 0
					this.selectedcount--
					if(this.objects[0] === "地理"){
						this.objects[0] = undefined
					}
					else if(this.objects[1] === "地理"){
						this.objects[1] = undefined
					}
				}
			}
			
export function objectchange()
			{
				if(this.button === 1){
					this.object = "专科"
					this.typeindex = 0
					this.batchindex = 0
				}
				else {
					this.object = "本科"
					this.typeindex = 0
					this.batchindex = 0
					
				}
			}
			
export function batch(){
				if(this.button === 0&&this.index === 0&&this.typeindex === 0){
					return this.ug_batch_phy_01
				}
				if(this.button === 0&&this.index === 0&&this.typeindex === 1){
					return this.ug_batch_phy_02
				}
				if(this.button === 0&&this.index === 0&&this.typeindex === 2){
					return this.ug_batch_phy_03
				}
				if(this.button === 0&&this.index === 0&&this.typeindex === 3){
					return this.ug_batch_phy_04
				}
				if(this.button === 0&&this.index === 1&&this.typeindex === 0){
					return this.ug_batch_his_01
				}
				if(this.button === 0&&this.index === 1&&this.typeindex === 1){
					return this.ug_batch_phy_02
				}
				if(this.button === 0&&this.index === 1&&this.typeindex === 2){
					return this.ug_batch_phy_03
				}
				if(this.button === 0&&this.index === 1&&this.typeindex === 3){
					return this.ug_batch_phy_04
				}
				
				if(this.button === 1&&this.index === 0&&this.typeindex === 0){
					return this.sk_batch_phy_01
				}
				if(this.button === 1&&this.index === 0&&this.typeindex === 1){
					return this.sk_batch_phy_02
				}
				if(this.button === 1&&this.index === 0&&this.typeindex === 2){
					return this.sk_batch_phy_03
				}
				if(this.button === 1&&this.index === 0&&this.typeindex === 3){
					return this.sk_batch_phy_04
				}
				if(this.button === 1&&this.index === 1&&this.typeindex === 0){
					return this.sk_batch_his_01
				}
				if(this.button === 1&&this.index === 1&&this.typeindex === 1){
					return this.sk_batch_phy_02
				}
				if(this.button === 1&&this.index === 1&&this.typeindex === 2){
					return this.sk_batch_phy_03
				}
				if(this.button === 1&&this.index === 1&&this.typeindex === 3){
					return this.sk_batch_phy_04
				}
			}
	
export function simulate() {
	
}