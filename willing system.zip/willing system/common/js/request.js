// const baseurl = 'https://xueliannet.com/api.php'
const baseurl = '/api.php'
// 解决登录过期时同一个页面多个请求重复触发跳转login页面问题
const loginDebounce = ()=>{}

// 错误处理
const errorHandler = (error, callback, lastToken) => {
  if (error?.statusCode === 401) {
    loginDebounce(lastToken)
  }
  typeof callback === 'function' && callback(error)
}
// 请求成功回调
const successHandler = (res, callback, errorCallback, lastToken) => {
  if (res.statusCode === 200) {
    if (typeof res.data === 'string') {
      try {
        res.data = JSON.parse(res.data)
      } catch (error) {
        console.log(error);
      }
    }
    const { code, message } = res.data || {}
    if (code === 200 || code === 1) {
      typeof callback === 'function' && callback(res.data)
    } else if (typeof code === 'undefined') {
      typeof callback === 'function' && callback(res.data)
    } else {
      if (code === 401 || (code === 500 && message.includes('Token无效'))) {
        loginDebounce(lastToken)
      }
      typeof errorCallback === 'function' && errorCallback(res.data)
    }
  } else {
    typeof errorHandler === 'function' && errorHandler(res, errorCallback, lastToken)
  }
}
// 请求封装
const request = opt => {
  const { url, method = 'GET',networkType = 'request', success, fail, complete, signal = {}, ...options } = opt || {} 
      options.header = {
      ...options.header || {},
    }
  if (success || fail || complete) {
    console.error('success|fail|complete已被过滤，请使用类axios风格api!');
  }
  if (!Object.prototype.toString.call(signal).includes('Object')) {
    signal = {}
  }
  return new Promise((resolve, reject) => {
    const task = uni[networkType]({
      url: (url.startsWith('http:') || url.startsWith('https:')) ? url : (baseurl + url),
      method,
      success: res => {
        successHandler(res, resolve, reject)
      }, fail: error => {
        errorHandler(error, reject)
      },
      complete: () => {
        signal.abort = null
      },
      ...options
    })
    signal.abort = () => {
      task.abort()
    }
  })
}
// 类axios风格二次封装
const methods = ['GET', 'POST', 'PUT', 'DELETE', 'uploadFile', 'connectSocket']
methods.forEach(type => {
  if (['GET', 'DELETE'].includes(type)) {
    request[type.toLowerCase()] = (...args) => {
      const [url, config] = args
      let params = {}
      if (config) {
        params = { ...config.params }
        delete config.params

      }
      return request({
        url,
        method: type,
        data: params,
        ...(config || {})
      })
    }
  }
  if (['POST', 'PUT'].includes(type)) {
    request[type.toLowerCase()] = (...args) => {
      const [url, data, config] = args
      return request({
        url,
        method: type,
        data,
        ...(config || {})
      })
    }
  }
  if (['uploadFile'].includes(type)) {
    request[type] = (...args) => {
      const [url, config] = args
      return request({
        url,
        networkType: type,
        ...(config || {})
      })
    }
  }
  if (['connectSocket'].includes(type)) {
    request[type] = (...args) => {
      const [url, config] = args
      return request({
        url,
        networkType: type,
        ...(config || {})
      })
    }
  }
})
export default request